import numpy as np
from scipy.optimize import curve_fit
# import matplotlib
# matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import statistics as s
import csv
import os,sys
from astropy.io import fits
import matplotlib.animation as animation
import pandas
import scipy.stats
import peakutils


#
# This is a collection of script that can be usefull in the interpretation of IR camera files
#



# SOMETHING USEFULL FOR PROFILING
#
#
# import cProfile
# import re
# cProfile.run(' SCRIPT OR SINGLE INSTRUCTION THAT I WANT TO PROFILE ')
#
#


def is_number(s):
    """ Returns True is string is a number. """
    try:
        float(s)
        return True
    except ValueError:
        return False

def rsquared(x, y):
    """ Return R^2 where x and y are array-like."""

    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(x, y)
    return r_value**2


#This function will generate a polinomial of n order GOOD FOR WHOLE FRAMES
def polygen(n):
	def polyadd(x, *params):
		params=np.array(params)
		shape=np.shape(x)
		temp=np.zeros(shape)
		# if (len(shape)>1) & (len(np.shape(params))==1):
		# 	params=np.reshape(params,(shape[-2],shape[-1],n))
		for i in range(n):
			# print('np.shape(temp),np.shape(params),np.shape(x)',temp,params,x)
			x2=np.power(x,i)
			# print('params[:][:][i]',params[:][:][i])
			# print('params',params)
			para=np.multiply(params[:,:,i],x2)
			temp=np.add(temp,para)
		return temp
	return polyadd

# #This function will generate a polinomial of n order GOOD FOR background fitting BUT NOT WORKING!! 2018/03/30
# def polygen2(n,shape):
# 	def polyadd(x, *params):
# 		params=np.array(params)
# 		x=np.reshape(x,shape)
# 		temp=np.zeros(shape)
# 		# if (len(shape)>1) & (len(np.shape(params))==1):
# 		params=np.reshape(params,(shape[-2],shape[-1],n))
# 		for i in range(n):
# 			# print('np.shape(temp),np.shape(params),np.shape(x)',temp,params,x)
# 			x2=np.power(x,i)
# 			# print('params[:][:][i]',params[:][:][i])
# 			# print('params',params)
# 			para=np.multiply(params[:,:,i],x2)
# 			temp=np.add(temp,para)
# 		return temp
# 	return polyadd

#This function will generate a polinomial of n order
def polygen3(n):
	def polyadd(x, *params):
		temp=0
		for i in range(n):
			temp+=params[i]*x**i
		return temp
	return polyadd


#############################################################################################

def order_filenames(filenames):

	# 13/05/2018 THIS FUNCTION IS INTODUCED TO FIX A BUG IN THE CASE filenames CONTAINS .npy FILES AND NOT .csv

	extention=filenames[0][-4:]
	if ((extention=='.csv') or (extention=='.CSV')):
		return order_filenames_csv(filenames)
	else:
		return sorted(filenames, key=str.lower)

######################################################################################################

def order_filenames_csv(filenames):

	# section to be sure that the files are ordered in the proper numeric order
	# CAUTION!! THE FOLDER MUST CONTAIN MAX 9999999 FILES!

	reference=[]
	filenamescorr=[]
	for i in range(len(filenames)):
		# print(filenames[i])
		start=0
		end=len(filenames[i])
		for j in range(len(filenames[i])):
			if ((filenames[i][j]=='-') or (filenames[i][j]=='_')): #modified 12/08/2018 from "_" to "-"
				start=j
			elif filenames[i][j]=='.':
				end=j
		index=filenames[i][start+1:end]
		#print('index',index)

		# Commented 21/08/2018
		# if int(index)<10:
		# 	temp=filenames[i][:start+1]+'000000'+filenames[i][end-1:]
		# 	filenamescorr.append(temp)
		# elif int(index)<100:
		# 	temp=filenames[i][:start+1]+'00000'+filenames[i][end-2:]
		# 	filenamescorr.append(temp)
		# 	# print(filenames[i],temp)
		# elif int(index)<1000:
		# 	temp=filenames[i][:start+1]+'0000'+filenames[i][end-3:]
		# 	filenamescorr.append(temp)
		# elif int(index)<10000:
		# 	temp=filenames[i][:start+1]+'000'+filenames[i][end-4:]
		# 	filenamescorr.append(temp)
		# elif int(index)<100000:
		# 	temp=filenames[i][:start+1]+'00'+filenames[i][end-5:]
		# 	filenamescorr.append(temp)
		# elif int(index)<1000000:
		# 	temp=filenames[i][:start+1]+'0'+filenames[i][end-6:]
		# 	filenamescorr.append(temp)
		# else:
		# 	filenamescorr.append(filenames[i])
		reference.append(index)
	reference=np.array(reference)
	filenamesnew=np.array([filenames for _,filenames in sorted(zip(reference,filenames))])

	# Commented 21/08/2018
	# filenamescorr=sorted(filenamescorr, key=str.lower)
	# filenamesnew=[]
	# for i in range(len(filenamescorr)):
	# 	# print(filenamescorr[i])
	# 	for j in range(len(filenamescorr[i])):
	# 		if ((filenames[i][j]=='-') or (filenames[i][j]=='_')): #modified 12/08/2018 from "_" to "-"
	# 			start=j
	# 		elif filenamescorr[i][j]=='.':
	# 			end=j
	# 	index=filenamescorr[i][start+1:end]
	# 	# if int(index)<10:
	# 	# 	temp=filenamescorr[i][:start+1]+str(int(index))+filenamescorr[i][end:]
	# 	# 	filenamesnew.append(temp)
	# 	# elif int(index)<100:
	# 	# 	temp=filenamescorr[i][:start+1]+str(int(index))+filenamescorr[i][end:]
	# 	# 	filenamesnew.append(temp)
	# 	# 	# print(filenames[i],temp)
	# 	# if int(index)<1000000:
	# 	temp=filenamescorr[i][:start+1]+str(int(index))+filenamescorr[i][end:]
	# 	filenamesnew.append(temp)
	# 	# 	# print(filenamescorr[i],temp)
	# 	# else:
	# 	# 	filenamesnew.append(filenamescorr[i])
	filenames=filenamesnew

	return(filenames)

#############################################################################################


def collect_subfolder(extpath):

	# THIS FUNCTION GENERATE THE .npy FILE CORRESPONDING TO A SINGLE FOLDER STARTING FROM ALL THE .csv FILES IN IT

	##print('sys.argv[0] =', sys.argv[0])
	#pathname = os.path.dirname(sys.argv[0])
	##print('path =', pathname)
	#print('full path =', os.path.abspath(pathname))
	#path=os.path.abspath(pathname)


	# path=os.getcwd()
	path=extpath
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)


	temp=[]
	print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='csv':
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')
	filenames=temp

	filenames=order_filenames(filenames)

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	with open(os.path.join(path,filename),'r') as csvfile:
		reader = csv.reader(csvfile)
		# print('reader',reader)
		pointer=0
		for row in reader:
	#		print('shape',np.shape(row))
			# print('row',row)
			if not row:
				temp='empty'
			else:
				temp=row[0]
			if (is_number(temp)) & (firstrow==-1):
				firstrow=pointer
				rowlen=np.shape(row)[0]
				pointer+=1
			elif is_number(temp) & firstrow>-1:
				pointer+=1
			else:
				ponter=0
	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen

	data=np.zeros((1,numfiles,sizey,sizex))

	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			tempdata=[]
			pointer=sizey-1
			for row in reader:
		#		print('shape',np.shape(row))
				# print('row',row)
				if not row:
					temp='empty'
				else:
					temp=row[0]
				if is_number(temp):
					for k in range(len(row)):
						# print('j,i,pointer,k',j,i,pointer,k)
						data[0,file,pointer,k]=(float(row[k]))
						# print('float(k)',float(row[k]))
					pointer-=1
					# print('row',row)
				else:
					ponter=0
			file+=1

	np.save(os.path.join(extpath,lastpath),data)

	# plt.pcolor(data[0,20,:,:])
	# plt.show()


##############################################################################################

def collect_subfolderfits(extpath):

	##print('sys.argv[0] =', sys.argv[0])
	#pathname = os.path.dirname(sys.argv[0])
	##print('path =', pathname)
	#print('full path =', os.path.abspath(pathname))
	#path=os.path.abspath(pathname)


	# path=os.getcwd()
	path=extpath
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)

	filefits=[]
	temp=[]
	print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='csv':
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')
		elif filenames[index][-3:]=='fts':
			filefits.append(filenames[index])
	filenames=temp
	filenames=sorted(filenames, key=str.lower)

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	with open(os.path.join(path,filename),'r') as csvfile:
		reader = csv.reader(csvfile)
		# print('reader',reader)
		pointer=0
		for row in reader:
	#		print('shape',np.shape(row))
			# print('row',row)
			if not row:
				temp='empty'
			else:
				temp=row[0]
			if (is_number(temp)) & (firstrow==-1):
				firstrow=pointer
				rowlen=np.shape(row)[0]
				pointer+=1
			elif is_number(temp) & firstrow>-1:
				pointer+=1
			else:
				ponter=0
	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen


	datafit=fits.open(os.path.join(path,filefits[0]))
	datafit=datafit[0].data

	datafit=datafit+32768
	lenfits=len(datafit)

	data=np.zeros((1,lenfits,sizey,sizex))
	datatest=np.zeros((1,numfiles,sizey,sizex))
	index=0
	for frame in datafit:
		# plt.pcolor(frame)
		# plt.show()
		frame=np.flip(frame,0)
		# plt.pcolor(frame)
		# plt.show()
		data[0,index,:,:]=frame
		index+=1


	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			tempdata=[]
			pointer=sizey-1
			for row in reader:
		#		print('shape',np.shape(row))
				# print('row',row)
				if not row:
					temp='empty'
				else:
					temp=row[0]
				if is_number(temp):
					for k in range(len(row)):
						# print('j,i,pointer,k',j,i,pointer,k)
						datatest[0,file,pointer,k]=(float(row[k]))
						# print('float(k)',float(row[k]))
					pointer-=1
					# print('row',row)
				else:
					ponter=0
			file+=1

	# if (not (np.array_equal(datatest[0,0],data[0,0]))):
	# 	print('there must be something wrong, the first frame of the FITS file do not match with the first csv files')
	# 	exit()
	if (not (np.array_equal(datatest[0,-1],data[0,-1]))):
		print('there must be something wrong, the last frame of the FITS file do not match with the last csv files')
		# exit()
	else:
		np.save(os.path.join(extpath,lastpath),data)

	# plt.pcolor(data[0,20,:,:])
	# plt.show()

##############################################################################################

def collect_subfolderfits_limited(extpath,start,stop):

	# 10/05/2018 THIS FUNCTION IS EXACLT LIKE collect_subfolderfits BUT LIMIT THE FILE CREATED FROM THE start FRAME TO THE  finish ONE

	##print('sys.argv[0] =', sys.argv[0])
	#pathname = os.path.dirname(sys.argv[0])
	##print('path =', pathname)
	#print('full path =', os.path.abspath(pathname))
	#path=os.path.abspath(pathname)


	# path=os.getcwd()
	path=extpath
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)

	filefits=[]
	temp=[]
	print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='csv':
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')
		elif filenames[index][-3:]=='fts':
			filefits.append(filenames[index])
	filenames=temp
	filenames=sorted(filenames, key=str.lower)

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	with open(os.path.join(path,filename),'r') as csvfile:
		reader = csv.reader(csvfile)
		# print('reader',reader)
		pointer=0
		for row in reader:
	#		print('shape',np.shape(row))
			# print('row',row)
			if not row:
				temp='empty'
			else:
				temp=row[0]
			if (is_number(temp)) & (firstrow==-1):
				firstrow=pointer
				rowlen=np.shape(row)[0]
				pointer+=1
			elif is_number(temp) & firstrow>-1:
				pointer+=1
			else:
				ponter=0
	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen


	datafit=fits.open(os.path.join(path,filefits[0]))
	datafit=datafit[0].data

	datafit=datafit+32767
	lenfits=len(datafit)

	data=np.zeros((1,lenfits,sizey,sizex))
	datatest=np.zeros((1,numfiles,sizey,sizex))
	index=0
	for frame in datafit:
		# plt.pcolor(frame)
		# plt.show()
		frame=np.flip(frame,0)
		# plt.pcolor(frame)
		# plt.show()
		data[0,index,:,:]=frame
		index+=1


	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			tempdata=[]
			pointer=sizey-1
			for row in reader:
		#		print('shape',np.shape(row))
				# print('row',row)
				if not row:
					temp='empty'
				else:
					temp=row[0]
				if is_number(temp):
					for k in range(len(row)):
						# print('j,i,pointer,k',j,i,pointer,k)
						datatest[0,file,pointer,k]=(float(row[k]))
						# print('float(k)',float(row[k]))
					pointer-=1
					# print('row',row)
				else:
					ponter=0
			file+=1

	if (np.array_equal(datatest[0,0],data[0,0]))&(np.array_equal(datatest[0,-1],data[0,-1])):
		print('there must be something wrong, the first or last frame of the TITS file do not match with the two csv files')
		exit()


	if start<0:
		start=0
	if start>lenfits:
		start=lenfits
	if stop>lenfits:
		stop=lenfits
	if stop<start:
		print('there must be something wrong, you are giving start frame higher than stop one')
		exit()
	datacropped=data[:,start:stop,:,:]

	np.save(os.path.join(extpath,lastpath),datacropped)

	# plt.pcolor(data[0,20,:,:])
	# plt.show()

##############################################################################################

# make movie

def movie(extpath,framerate,integration,xlabel=(),ylabel=(),barlabel=(),cmap='rainbow'):

	path=extpath
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)

	filefits=[]
	temp=[]
	filemovie=[]
	print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='npy':
			temp.append(filenames[index])

	filenames=temp
	filenames=sorted(filenames, key=str.lower)

	numfiles=len(filenames)


	filename=filenames[0]

	data=np.load(os.path.join(path,filename))

	fig = plt.figure()
	ax = fig.add_subplot(111)

	# I like to position my colorbars this way, but you don't have to
	# div = make_axes_locatable(ax)
	# cax = div.append_axes('right', '5%', '5%')

	# def f(x, y):
	#     return np.exp(x) + np.sin(y)

	# x = np.linspace(0, 1, 120)
	# y = np.linspace(0, 2 * np.pi, 100).reshape(-1, 1)

	# This is now a list of arrays rather than a list of artists
	frames = [None]*len(data[0])
	frames[0]=data[0,0]

	for i in range(len(data[0])):
	    # x       += 1
	    # curVals  = f(x, y)
	    frames[i]=(data[0,i])

	cv0 = frames[0]
	im = ax.imshow(cv0,cmap, origin='lower') # Here make an AxesImage rather than contour
	cb = fig.colorbar(im).set_label(barlabel)
	cb = ax.set_xlabel(xlabel)
	cb = ax.set_ylabel(ylabel)
	tx = ax.set_title('Frame 0')

	def animate(i):
	    arr = frames[i]
	    vmax     = np.max(arr)
	    vmin     = np.min(arr)
	    im.set_data(arr)
	    im.set_clim(vmin, vmax)
	    tx.set_text('Frame {0}'.format(i)+', FR '+str(framerate)+'Hz, t '+str(np.around(0+i/framerate,decimals=3))+'s int '+str(integration)+'ms')
	    # In this version you don't have to do anything to the colorbar,
	    # it updates itself when the mappable it watches (im) changes

	ani = animation.FuncAnimation(fig, animate, frames=len(data[0]))

	ani.save(os.path.join(extpath,lastpath)+'.mp4', fps=30, extra_args=['-vcodec', 'libx264'])


######################################################################################################

def movie_from_data(data,framerate,integration=1,xlabel=(),ylabel=(),barlabel=(),cmap='rainbow',timesteps='auto',extvmin='auto',extvmax='auto'):

	fig = plt.figure()
	ax = fig.add_subplot(111)

	# I like to position my colorbars this way, but you don't have to
	# div = make_axes_locatable(ax)
	# cax = div.append_axes('right', '5%', '5%')

	# def f(x, y):
	#     return np.exp(x) + np.sin(y)

	# x = np.linspace(0, 1, 120)
	# y = np.linspace(0, 2 * np.pi, 100).reshape(-1, 1)

	# This is now a list of arrays rather than a list of artists
	frames = [None]*len(data[0])
	frames[0]=data[0,0]

	for i in range(len(data[0])):
	    # x       += 1
	    # curVals  = f(x, y)
	    frames[i]=(data[0,i])

	cv0 = frames[0]
	im = ax.imshow(cv0,cmap, origin='lower') # Here make an AxesImage rather than contour


	cb = fig.colorbar(im).set_label(barlabel)
	cb = ax.set_xlabel(xlabel)
	cb = ax.set_ylabel(ylabel)
	tx = ax.set_title('Frame 0')


	if timesteps=='auto':
		def animate(i):
			arr = frames[i]
			if extvmax!='auto':
				vmax=extvmax
			else:
				vmax     = np.max(arr)
			if extvmin!='auto':
				vmin=extvmin
			else:
				vmin     = np.min(arr)
			im.set_data(arr)
			im.set_clim(vmin, vmax)
			tx.set_text('Frame {0}'.format(i)+', FR '+str(framerate)+'Hz, t '+str(np.around(0+i/framerate,decimals=3))+'s int '+str(integration)+'ms')

		    # In this version you don't have to do anything to the colorbar,
		    # it updates itself when the mappable it watches (im) changes
	else:
		def animate(i):
			arr = frames[i]
			vmax     = np.max(arr)
			vmin     = np.min(arr)
			im.set_data(arr)
			im.set_clim(vmin, vmax)
			tx.set_text('Frame {0}'.format(i)+', t '+str(timesteps[i])+'s int '+str(integration)+'ms')

	ani = animation.FuncAnimation(fig, animate, frames=len(data[0]))

	return ani


######################################################################################################


def collect_stat(extpath):

	##print('sys.argv[0] =', sys.argv[0])
	#pathname = os.path.dirname(sys.argv[0])
	##print('path =', pathname)
	#print('full path =', os.path.abspath(pathname))
	#path=os.path.abspath(pathname)


	# path=os.getcwd()
	path=extpath
	print('path =', path)


	filenames=all_file_names(path,'stat.npy')
	#
	# position=[]
	# for i in range(len(path)):
	# 	if path[i]=='/':
	# 		position.append(i)
	# position=max(position)
	# lastpath=path[position+1:]
	# # print('lastpath',lastpath)
	#
	# f = []
	# for (dirpath, dirnames, filenames) in os.walk(path):
	# 	f.extend(filenames)
	# #	break
	#
	# filenames=f
	# # print('filenames',filenames)
	#
	# filefits=[]
	# temp=[]
	# print('len(filenames)',len(filenames))
	# for index in range(len(filenames)):
	# 	# print(filenames[index])
	# 	if filenames[index][-8:]=='stat.npy':
	# 		temp.append(filenames[index])
	# 		# filenames=np.delete(filenames,index)
	# 		# print('suca')
	# filenames=temp
	# filenames=sorted(filenames, key=str.lower)
	#
	# numfiles=len(filenames)


	filename=filenames[0]

	data=np.load(os.path.join(extpath,filename))

	return data

########################################################################################################


def evaluate_back(extpath):

	# THIS FUNCTION PREPARE THE FILES THAT WILL BE USED FOR GETTING THE COUNTS TO TEMPERATURE CALIBRATION
	#
	# UPDATE 10/05/2018 I FOUND AN ERROR AND CHANGED datastat[0]=np.mean(data,axis=(-1,-2))  TO   datastat[0]=np.mean(data,axis=(0,1))

	##print('sys.argv[0] =', sys.argv[0])
	#pathname = os.path.dirname(sys.argv[0])
	##print('path =', pathname)
	#print('full path =', os.path.abspath(pathname))
	#path=os.path.abspath(pathname)

	path=extpath
	# path=os.getcwd()
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=sorted(filenames, key=str.lower)
	temp=[]
	# print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='npy':
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')

	filenames=temp

	#filenames=np.delete(filenames,0)
	numfiles=len(filenames)


	print('filenames',filenames)


	data=np.load(os.path.join(path,filenames[0]))
	datashape=np.shape(data)[-2:]

	datastatshape=[2]
	datastatshape.extend(datashape)
	datastat=np.zeros(datastatshape)

	print('np.shape(datastatshape)',np.shape(datastat))

	datastat[0]=np.mean(data,axis=(0,1))
	datastat[1]=np.std(data,axis=(0,1))

	# for i in range(datashape[0]):
	# 	for j in range(datashape[1]):
	# 		datastat[0,i,j]=np.mean(data[0,:,i,j])
	# 		datastat[1,i,j]=np.std(data[0,:,i,j])

	# datastat.extend([np.mean(data[0,:,:,:]),np.std(data[0,:,:,:])])
	# datastat[2]=np.std(data[0,:,:,:])

	# plt.pcolor(datastat[0])
	# plt.colorbar()
	# plt.figure()
	# plt.pcolor(datastat[1])
	# plt.colorbar()
	# plt.show()

	datastat=datastat.tolist()
	datastat.append([np.mean(data[0,:,:,:]),np.std(data[0,:,:,:])])

	np.save(os.path.join(extpath,lastpath+'_stat'),datastat)

######################################################################################################################

def all_file_names(extpath,type):

	# This utility returns a list with all filenames of a defined type in a given folder, orderen alphabetically and in number

	# path=os.getcwd()
	path=extpath
	print('path =', path)

	# position=[]
	# for i in range(len(path)):
	# 	if path[i]=='/':
	# 		position.append(i)
	# position=max(position)
	# lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)


	temp=[]

	typelen=len(type)
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-typelen:]==type:
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')
	filenames=temp

	if len(filenames)==0:
		print('ERROR - there are no files of type '+type+' in path '+path)
		return ()

	if len(filenames)==1:
		print('len(filenames)',len(filenames))
		return filenames

	filenames=order_filenames(filenames)

	print('len(filenames)',len(filenames))
	return filenames

######################################################################################################

def read_csv(extpath,filenames):

	# SLOW VERSION OF READ_CSV WITH csv.reader

	path=extpath
	print('path =', path)

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	with open(os.path.join(path,filename),'r') as csvfile:
		reader = csv.reader(csvfile)
		# print('reader',reader)
		pointer=0
		for row in reader:
	#		print('shape',np.shape(row))
			# print('row',row)
			if not row:
				temp='empty'
			else:
				temp=row[0]
			if (is_number(temp)) & (firstrow==-1):
				firstrow=pointer
				rowlen=np.shape(row)[0]
				pointer+=1
			elif is_number(temp) & firstrow>-1:
				pointer+=1
			else:
				ponter=0
	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen


	data=np.zeros((1,numfiles,sizey,sizex))

	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			tempdata=[]
			pointer=sizey-1
			for row in reader:
		#		print('shape',np.shape(row))
				# print('row',row)
				if not row:
					temp='empty'
				else:
					temp=row[0]
				if is_number(temp):
					for k in range(len(row)):
						# print('j,i,pointer,k',j,i,pointer,k)
						data[0,file,pointer,k]=(float(row[k]))
						# print('float(k)',float(row[k]))
					pointer-=1
					# print('row',row)
				else:
					ponter=0
			file+=1

	return data

###########################################################################################################

def read_csv2(extpath,filenames):

	# FAST VERSION OF READ_CVS WITH PANDA READER

	path=extpath
	print('path =', path)

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	csvfile=path+'/'+filename
	reader = pandas.read_csv(csvfile,sep='\r')
	reader=reader.values
	# print('reader',reader)
	pointer=0
	for row in reader:
#		print('shape',np.shape(row))
		# print('row',row)
		# if np.fromstring(row[0],sep=',').size>0:
			# print('sti cazzi2')
			# print(row)
		# print((np.fromstring(row[0],sep=',')).size>0)
		if (((np.fromstring(row[0],sep=',')).size>0) & (firstrow==-1)):
			# print((np.fromstring(row[0],sep=',')).size>0)
			# print('pointer,firstrow',pointer,firstrow)
			firstrow=pointer
			rowlen=np.shape(np.fromstring(row[0],sep=','))[0]
			pointer+=1
		# elif ((np.fromstring(row[0],sep=',')).size>0) & (firstrow>-1):
		# 	pointer+=1
		else:
			pointer+=1

	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen


	data=np.zeros((1,numfiles,sizey,sizex))

	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		csvfile=path+'/'+filename
		# print('csvfile',csvfile)
		reader = pandas.read_csv(csvfile,sep='\r')
		reader=reader.values
		reader=np.delete(reader,(np.linspace(0,firstrow-1,firstrow).astype(int)))
		# print('reader',reader)
		tempdata=[]
		pointer=sizey-1
		# pointer=sizey-1
		for row in reader:
			# tempdata.append(row[0])
			# tempdata=np.array(tempdata[firstrow:])
			data[0,file,pointer]=np.fromstring(row,sep=',')
			# print('np.fromstring(row[0],sep=',')',row)
			pointer-=1
		file+=1
	# data=data.astype(float)
	# print('suca')
	return data

###########################################################################################################


def read_fits(extpath,filenames,filefits):

	if len(filenames)>2:
		print('this is wrong! to make this function work toy must provide as second agrument the first and last frame of the movie as .csv')
		exit()

	numfiles=len(filenames)


	filename=filenames[0]

	# print('os.path.join(path,filename)',os.path.join(path,filename))

	firstrow=-1
	with open(os.path.join(path,filename),'r') as csvfile:
		reader = csv.reader(csvfile)
		# print('reader',reader)
		pointer=0
		for row in reader:
	#		print('shape',np.shape(row))
			# print('row',row)
			if not row:
				temp='empty'
			else:
				temp=row[0]
			if (is_number(temp)) & (firstrow==-1):
				firstrow=pointer
				rowlen=np.shape(row)[0]
				pointer+=1
			elif is_number(temp) & firstrow>-1:
				pointer+=1
			else:
				ponter=0
	lastrow=pointer
	sizey=lastrow-firstrow
	sizex=rowlen


	datafit=fits.open(os.path.join(path,filefits[0]))
	datafit=datafit[0].data

	datafit=datafit+32767
	lenfits=len(datafit)

	data=np.zeros((1,lenfits,sizey,sizex))
	datatest=np.zeros((1,numfiles,sizey,sizex))
	index=0
	for frame in datafit:
		# plt.pcolor(frame)
		# plt.show()
		frame=np.flip(frame,0)
		# plt.pcolor(frame)
		# plt.show()
		data[0,index,:,:]=frame
		index+=1


	print('firstrow,lastrow,sizey,sizex',firstrow,lastrow,sizey,sizex)

	file=0
	for filename in filenames:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			tempdata=[]
			pointer=sizey-1
			for row in reader:
		#		print('shape',np.shape(row))
				# print('row',row)
				if not row:
					temp='empty'
				else:
					temp=row[0]
				if is_number(temp):
					for k in range(len(row)):
						# print('j,i,pointer,k',j,i,pointer,k)
						datatest[0,file,pointer,k]=(float(row[k]))
						# print('float(k)',float(row[k]))
					pointer-=1
					# print('row',row)
				else:
					ponter=0
			file+=1

	if (np.array_equal(datatest[0,0],data[0,0]))&(np.array_equal(datatest[0,-1],data[0,-1])):
		print('there must be something wrong, the first or last frame of the TITS file do not match with the two csv files')
		exit()

	return data

################################################################################################

def count_to_temp_poly(data,params,errparams,errdata=(0,0)):
	print('ERROR: count_to_temp_poly was deleted 2018/04/02 because count_to_temp_poly2 has a better formulation for the error')
	exit()

	polygrade=len(params[0,0])

	shape=np.shape(data)
	datatemp=np.zeros(shape)

	if np.max(errdata)==0:
		errdata=np.zeros(shape)

	errdatatemp=np.zeros(shape)
	numframes=shape[1]
	sizey=shape[-2]
	sizex=shape[-1]
	sumi2=sum(np.power(np.linspace(1,polygrade-1,polygrade-1),2))

	# OLD VERSION WHEN POLYGEN WAS ABLE TO PRECESSO ONLY SCALARS 2018/03/29
	# for i in range(numframes):
	# 	for j in range(sizey):
	# 		index=0
	# 		for count in data[0,i,j]:
	# 			datatemp[0,i,j,index]=polygen(polygrade)(count,*params[j,index])
	# 			errdatatemp[0,i,j,index]=count*np.sqrt(sum([sumi2*errdata[0,i,j,index]**2/count**2]+np.power(np.divide(errparams[j,index],params[j,index]),2)))
	# 			index+=1

	paramerr=np.sum(np.power(np.divide(errparams,params),2),axis=-1)
	index=0
	for frame in data[0]:
		# print('np.shape(frame)',np.shape(frame))
		# print('np.shape(params)',np.shape(params))
		datatemp[0,index]=polygen(polygrade)(frame,*params)
		errdatatemp[0,index]=np.multiply(datatemp[0,index],np.sqrt(np.add(sumi2*np.divide(np.power(errdata[0,index],2),np.power(frame,2)),paramerr)))
		index+=1

	return datatemp,errdatatemp

################################################################################################

def count_to_temp_poly2(data,params,errparams,errdata=(0,0)):

	polygrade=len(params[0,0])

	shape=np.shape(data)
	datatemp=np.zeros(shape)

	if np.max(errdata)==0:
		errdata=np.zeros(shape)

	errdatatemp=np.zeros(shape)
	numframes=shape[1]
	sizey=shape[-2]
	sizex=shape[-1]
	#sumi2=sum(np.power(np.linspace(1,polygrade-1,polygrade-1),2))

	# paramerr=np.sum(np.power(np.divide(errparams,params),2),axis=-1)
	index=0
	for frame in data[0]:
		# print('np.shape(frame)',np.shape(frame))
		# print('np.shape(params)',np.shape(params))
		datatemp[0,index]=polygen(polygrade)(frame,*params)
		temp=0
		for i in range(polygrade):
			temp+=np.power(np.multiply(errparams[:,:,i],np.power(frame,i)),2)
			if i>0:
				temp+=np.power(np.multiply(np.multiply(np.multiply(params[:,:,i],np.power(frame,i-1)),i),errdata[0,index]),2)
		# errdatatemp[0,index]=np.sqrt(np.add(sumi2*np.divide(np.power(errdata[0,index],2),np.power(frame,2)),paramerr))
		errdatatemp[0,index]=np.sqrt(temp)
		index+=1

	return datatemp,errdatatemp

################################################################################################

def build_poly_coeff(temperature,files,int,path,nmax):
	# modified 2018-10-08 to build the coefficient only for 1 degree of polinomial
	while np.shape(temperature[0])!=():
		temperature=np.concatenate(temperature)
		files=np.concatenate(files)
	meancounttot=[]
	meancountstdtot=[]
	for file in files:
		data=collect_stat(file)
		meancounttot.append(np.array(data[0]))
		meancountstdtot.append(np.array(data[1]))

	meancounttot=np.array(meancounttot)
	meancountstdtot=np.array(meancountstdtot)
	# nmax=5
	shapex=np.shape(meancounttot[0])[0]
	shapey=np.shape(meancounttot[0])[1]
	score=np.zeros((nmax-1,shapex,shapey))

	#for n in range(2,nmax+1):
	n=nmax
	guess=np.ones(n)
	guess,temp2=curve_fit(polygen3(n), meancounttot[:,0,0],temperature, p0=guess, maxfev=100000000)

	coeff=np.zeros((shapex,shapey,n))
	errcoeff=np.zeros((shapex,shapey,n))

	for j in range(shapex):
		for k in range(shapey):
			x=np.array(meancounttot[:,j,k])
			xerr=np.array(meancountstdtot[:,j,k])
			temp1,temp2=curve_fit(polygen3(n),x, temperature, p0=guess, maxfev=100000000)
			yerr=(polygen3(n)((x+xerr),*temp1)-polygen3(n)((x-xerr),*temp1))/2
			temp1,temp2=curve_fit(polygen3(n),x, temperature, p0=temp1, sigma=yerr, maxfev=100000000)
			# yerr=(polygen3(n)((x+xerr),*temp1)-polygen3(n)((x-xerr),*temp1))/2
			guess=temp1
			coeff[j,k,:]=temp1
			errcoeff[j,k,:]=np.sqrt(np.diagonal(temp2))
			score[n-2,j,k]=rsquared(temperature,polygen3(n)(x,*temp1))
	np.save(os.path.join(path,'coeffpolydeg'+str(n)+'int'+str(int)+'ms'),coeff)
	np.save(os.path.join(path,'errcoeffpolydeg'+str(n)+'int'+str(int)+'ms'),errcoeff)

	print('for a polinomial of degree '+str(n-1)+' the R^2 score is '+str(np.sum(score[n-2])))


###############################################################################################################

def build_poly_coeff2(temperature,files,int,path,nmax):
	print('ERROR: builf_poly_coeff2 was deleted 2018/04/02 because curve_fit must be used without the flag absolute_sigma=True on for significant parameters covariance matrix')
	exit()

	while np.shape(temperature[0])!=():
		temperature=np.concatenate(temperature)
		files=np.concatenate(files)
	meancounttot=[]
	meancountstdtot=[]
	for file in files:
		data=collect_stat(file)
		meancounttot.append(np.array(data[0]))
		meancountstdtot.append(np.array(data[1]))

	meancounttot=np.array(meancounttot)
	meancountstdtot=np.array(meancountstdtot)
	# nmax=5
	shapex=np.shape(meancounttot[0])[0]
	shapey=np.shape(meancounttot[0])[1]
	score=np.zeros((nmax-1,shapex,shapey))

	for n in range(2,nmax+1):
		guess=np.ones(n)
		guess,temp2=curve_fit(polygen3(n), meancounttot[:,0,0],temperature, p0=guess, maxfev=100000000)

		coeff=np.zeros((shapex,shapey,n))
		errcoeff=np.zeros((shapex,shapey,n))

		for j in range(shapex):
			for k in range(shapey):
				x=np.array(meancounttot[:,j,k])
				xerr=np.array(meancountstdtot[:,j,k])
				temp1,temp2=curve_fit(polygen3(n),x, temperature, p0=guess,absolute_sigma=True)
				yerr=(polygen3(n)((x+xerr),*temp1)-polygen3(n)((x-xerr),*temp1))/2
				temp1,temp2=curve_fit(polygen3(n),x, temperature, p0=temp1, sigma=yerr, maxfev=100000000,absolute_sigma=True)
				yerr=(polygen3(n)((x+xerr),*temp1)-polygen3(n)((x-xerr),*temp1))/2
				guess=temp1
				coeff[j,k,:]=temp1
				errcoeff[j,k,:]=np.sqrt(np.diagonal(temp2))
				score[n-2,j,k]=rsquared(temperature,polygen3(n)(x,*temp1))
		np.save(os.path.join(path,'coeffpolydeg'+str(n)+'int'+str(int)+'ms'),coeff)
		np.save(os.path.join(path,'errcoeffpolydeg'+str(n)+'int'+str(int)+'ms'),errcoeff)

		print('for a polinomial with '+str(n)+' coefficients the R^2 score is '+str(np.sum(score[n-2])))

################################################################################################

def build_multiple_poly_coeff(temperaturehot,temperaturecold,fileshot,filescold,inttime,framerate,pathparam,nmax):
	# 08/10/2018 THIS CALCULATE FROM MULTIPLE HOT>ROOM AND COLD >ROOM CYCLES THE COEFFICIENTS FOR ALL THE POSSIBLE COMBINATIONS

	for i in range(len(temperaturehot)):
		temperaturehot[i]=flatten_full(temperaturehot[i])
	for i in range(len(temperaturecold)):
		temperaturecold[i]=flatten_full(temperaturecold[i])
	for i in range(len(fileshot)):
		fileshot[i]=flatten_full(fileshot[i])
	for i in range(len(filescold)):
		filescold[i]=flatten_full(filescold[i])

	for i in range(len(temperaturehot)):
		if len(temperaturehot[i])!=len(fileshot[i]):
			print('Error, temperaturehot'+str(i)+' and fileshot'+str(i)+' length is different')
			exit()
	for i in range(len(temperaturecold)):
		if len(temperaturecold[i])!=len(filescold[i]):
			print('Error, temperaturecold'+str(i)+' and filescold'+str(i)+' length is different')
			exit()

	lengthhot=len(temperaturehot)
	lengthcold=len(temperaturecold)

	# This lies must be placed outside of the function to make it work
	# fileshot=np.array([fileshot1,fileshot2])
	# temperaturehot=np.array([temperaturehot1,temperaturehot2])
	# filescold=np.array([filescold1,filescold2])
	# temperaturecold=np.array([temperaturecold1,temperaturecold2])

	# THIS COMPUTE THE 1-1, 1-2, 2-1, 2-2 PARAMETERS
	for i in range(lengthhot):
		for j in range(lengthcold):
			path=pathparam+'/'+str(inttime)+'ms'+str(framerate)+'Hz'+'/'+'numcoeff'+str(nmax)+'/'+str(i+1)+'-'+str(j+1)
			if not os.path.exists(path):
				os.makedirs(path)
			temperature=[temperaturehot[i],temperaturecold[j]]
			files=[fileshot[i],filescold[j]]
			build_poly_coeff(temperature,files,inttime,path,nmax)

################################################################################################

def build_average_poly_coeff(temperaturehot,temperaturecold,fileshot,filescold,inttime,framerate,pathparam,nmax):
	# 08/10/2018 THIS MAKES THE AVERAGE OF COEFFICIENTS FROM MULTIPLE HOT>ROOM AND COLD >ROOM CYCLES THE COEFFICIENTS

	lengthhot=len(temperaturehot)
	lengthcold=len(temperaturecold)

	first=True
	for i in range(lengthhot):
		for j in range(lengthcold):
			path=pathparam+'/'+str(inttime)+'ms'+str(framerate)+'Hz'+'/'+'numcoeff'+str(nmax)+'/'+str(i+1)+'-'+str(j+1)
			params=np.load(os.path.join(path,'coeffpolydeg'+str(nmax)+'int'+str(inttime)+'ms'+'.npy'))
			if first==True:
				shape=np.shape(params)
				shape=np.concatenate(((lengthhot,lengthcold),shape))
				parameters=np.zeros(shape)
				first=False
			parameters[i,j]=params

	meanparameters=np.mean(parameters,axis=(0,1))
	stdparameters=np.std(parameters,axis=(0,1))

	path=pathparam+'/'+str(inttime)+'ms'+str(framerate)+'Hz'+'/'+'numcoeff'+str(nmax)+'/average'
	if not os.path.exists(path):
		os.makedirs(path)
	np.save(os.path.join(path,'coeffpolydeg'+str(nmax)+'int'+str(inttime)+'ms'),meanparameters)
	np.save(os.path.join(path,'errcoeffpolydeg'+str(nmax)+'int'+str(inttime)+'ms'),stdparameters)


#####################################################################################################

def average_frame(frame,pixelmean,extremedelete=False):

	# Does the average over pixelmean x pixelmean pixels of frame
	#
	# If the flag extremedelete is True for every mean the maximuna and minimum values are deleted
	#

	shapeorig=np.shape(frame)
	shapeaver=(np.ceil(np.divide(shapeorig,pixelmean))).astype(int)
	frameaver=np.zeros(shapeaver)
	for i in range(shapeaver[0]):
		if ((i+1)*pixelmean)>shapeorig[0]:
			indexi=shapeorig[0]-1
		else:
			indexi=(i+1)*pixelmean
		for j in range(shapeaver[1]):
			if ((j+1)*pixelmean)>shapeorig[1]:
				indexj=shapeorig[1]-1
			else:
				indexj=(j+1)*pixelmean
			flat=np.ravel(frame[i*pixelmean:int(indexi),j*pixelmean:int(indexj)])
			if extremedelete==True:
				if len(flat)>3:
					flat=np.delete(flat,np.argmax(flat))
					flat=np.delete(flat,np.argmin(flat))
			frameaver[i,j]=np.mean(flat)
			# print(i*pixelmean,indexi,j*pixelmean,indexj,flat)

	return frameaver

#####################################################################################################

def average_multiple_frames(frames,pixelmean,extremedelete=False):

	# Does the average over pixelmean x pixelmean pixels of multiple frames
	#
	# If the flag extremedelete is True for every mean the maximuna and minimum values are deleted
	#

	shapeorig=np.shape(frames)
	nframes=shapeorig[1]
	framesaver=[]
	framesaver.append([None]*nframes)
	framesaver=np.array(framesaver)
	for i in range(nframes):
		framesaver[0,i]=average_frame(frames[0,i],pixelmean,extremedelete)

	return framesaver

#####################################################################################################

def flatten(array):

	# 11/06/2018
	# This function flatten any array of one level.
	# If it is already in one level it return is the way it is
	#
	array=np.array(array)
	length=np.shape(array)[0]

	done=0
	for item in array:
		if np.shape(item)!=():
			done+=1
	if done==0:
		return array

	temp=[]
	lengthinside=np.zeros(length)
	for i in range(length):
		temp2=np.array(array[i])
		lengthinside=np.shape(temp2)
		if lengthinside==():
			temp.append(array[i])
		else:
			for j in range(lengthinside[0]):
				temp.append(temp2[j])
	temp=np.array(temp)
	return temp

#####################################################################################################

def flatten_full(array):
	# this function flatten an array fully

	while np.shape(array[0])!=():
		array=flatten(array)

	return array

#####################################################################################################

def ddx(array,dx,axis,otheraxis=(),howcropotheraxis=0):

	# this function makes the central difference derivative on the axis AXIS. it reduces the size of the array in that direction by two pixels
	# at the same time it can reduce the size ao the array in other directions too of any number of pixels.

	if axis==0:
		temp=np.divide(array[2:]-array[:-2],2*dx)
	elif axis==1:
		temp=np.divide(array[:,2:]-array[:,:-2],2*dx)
	elif axis==2:
		temp=np.divide(array[:,:,2:]-array[:,:,:-2],2*dx)
	elif axis==3:
		temp=np.divide(array[:,:,:,2:]-array[:,:,:,:-2],2*dx)
	elif axis==4:
		temp=np.divide(array[:,:,:,:,2:]-array[:,:,:,:,:-2],2*dx)
	elif axis==5:
		temp=np.divide(array[:,:,:,:,:,2:]-array[:,:,:,:,:,:-2],2*dx)
	elif axis==6:
		temp=np.divide(array[:,:,:,:,:,:,2:]-array[:,:,:,:,:,:,:-2],2*dx)


	if howcropotheraxis==0:
		return temp

	if otheraxis==():
		print('if you specify the number of pixels to crop tou must specify too the axis where to do that')
		exit()

	numaxis=len(np.shape(array))
	for i in range(len(otheraxis)):
		if otheraxis[i]<0:
			otheraxis[i]=numaxis-otheraxis[i]

	if howcropotheraxis/2-howcropotheraxis//2!=0:
		print('the amount of pixels you want to crop the array must be even, to crop of half on one side and half on the other')
		exit()
	htc=howcropotheraxis//2
	if 0 in otheraxis:
		temp=temp[htc:-htc]
	if 1 in otheraxis:
		temp=temp[:,htc:-htc]
	if 2 in otheraxis:
		temp=temp[:,:,htc:-htc]
	if 3 in otheraxis:
		temp=temp[:,:,:,htc:-htc]
	if 4 in otheraxis:
		temp=temp[:,:,:,:,htc:-htc]
	if 5 in otheraxis:
		temp=temp[:,:,:,:,:,htc:-htc]
	if 6 in otheraxis:
		temp=temp[:,:,:,:,:,:,htc:-htc]

	return temp

#####################################################################################################

def d2dx2(array,dx,axis,otheraxis=(),howcropotheraxis=0):

	# this function makes the tentral difference second derivative on the axis AXIS. it reduces the size of the array in that direction by two pixels
	# at the same time it can reduce the size ao the array in other directions too of any number of pixels.

	if axis==0:
		temp=np.divide(array[2:]-np.multiply(2,array[1:-1])+array[:-2],dx**2)
	elif axis==1:
		temp=np.divide(array[:,2:]-np.multiply(2,array[:,1:-1])+array[:,:-2],dx**2)
	elif axis==2:
		temp=np.divide(array[:,:,2:]-np.multiply(2,array[:,:,1:-1])+array[:,:,:-2],dx**2)
	elif axis==3:
		temp=np.divide(array[:,:,:,2:]-np.multiply(2,array[:,:,:,1:-1])+array[:,:,:,:-2],dx**2)
	elif axis==4:
		temp=np.divide(array[:,:,:,:,2:]-np.multiply(2,array[:,:,:,:,1:-1])+array[:,:,:,:,:-2],dx**2)
	elif axis==5:
		temp=np.divide(array[:,:,:,:,:,2:]-np.multiply(2,array[:,:,:,:,:,1:-1])+array[:,:,:,:,:,:-2],dx**2)
	elif axis==6:
		temp=np.divide(array[:,:,:,:,:,:,2:]-np.multiply(2,array[:,:,:,:,:,:,1:-1])+array[:,:,:,:,:,:,:-2],dx**2)


	if howcropotheraxis==0:
		return temp
	if howcropotheraxis/2-howcropotheraxis//2!=0:
		print('the amount of pixels you want to crop the array must be even, to crop of half on one side and half on the other')
		exit()

	numaxis=len(np.shape(array))
	for i in range(len(otheraxis)):
		if otheraxis[i]<0:
			otheraxis[i]=numaxis-otheraxis[i]

	if howcropotheraxis/2-howcropotheraxis//2!=0:
		print('the amount of pixels you want to crop the array must be even, to crop of half on one side and half on the other')
		exit()
	htc=howcropotheraxis//2
	if 0 in otheraxis:
		temp=temp[htc:-htc]
	if 1 in otheraxis:
		temp=temp[:,htc:-htc]
	if 2 in otheraxis:
		temp=temp[:,:,htc:-htc]
	if 3 in otheraxis:
		temp=temp[:,:,:,htc:-htc]
	if 4 in otheraxis:
		temp=temp[:,:,:,:,htc:-htc]
	if 5 in otheraxis:
		temp=temp[:,:,:,:,:,htc:-htc]
	if 6 in otheraxis:
		temp=temp[:,:,:,:,:,:,htc:-htc]

	return temp


#####################################################################################################

def save_timestamp(extpath):

	# 09/08/2018 This function lools at the CSV files and saves the timestamp of the firs and last one in a _timestamp.npy file

	# path=os.getcwd()

	path=extpath
	print('path =', path)

	position=[]
	for i in range(len(path)):
		if path[i]=='/':
			position.append(i)
	position=max(position)
	lastpath=path[position+1:]
	# print('lastpath',lastpath)

	f = []
	for (dirpath, dirnames, filenames) in os.walk(path):
		f.extend(filenames)
	#	break

	filenames=f
	# print('filenames',filenames)

	filefits=[]
	temp=[]
	print('len(filenames)',len(filenames))
	for index in range(len(filenames)):
		# print(filenames[index])
		if filenames[index][-3:]=='csv':
			temp.append(filenames[index])
			# filenames=np.delete(filenames,index)
			# print('suca')
		# elif filenames[index][-3:]=='fts':
		# 	filefits.append(filenames[index])
	filenames=temp
	filenames=sorted(filenames, key=str.lower)

	timestamp=[]
	# file=0
	for filename in [filenames[0],filenames[-1]]:
		with open(os.path.join(path,filename),'r') as csvfile:
			reader = csv.reader(csvfile)
			# print('reader',reader)
			for row in reader:
				if not not row:
				# else:
					if row[0][0:4]=='Time':
						time=row[0][7:]
						ampm=int(time[0:3])
						hh=int(time[4:6])
						mm=int(time[7:9])
						ss=float(time[10:])
						timess=ss+60*(mm+60*(hh+ampm*12))
						timestamp.append(timess)



	timestamp.append(np.mean(timestamp))
	timestamp=np.array(timestamp)
	np.save(os.path.join(extpath,lastpath+'_timestamp'),timestamp)


####################################################################################################

def search_background_timestamp(extpath,ref_directory):

	# 09/08/2018 This function lools at the timestamp in "extpath" and compare it with all the timestamps in the directories indicated by "ref_directory"
	# then I pick the two that are closer and interpolate in between the two to get the proper background


	ref_directories=[]
	for (dirpath, dirnames, filenames) in os.walk(ref_directory):
		ref_directories.extend(dirnames)


	ref_directories=order_filenames(ref_directories)

	type="_timestamp.npy"
	time=[]
	for directory in ref_directories:
		filename=all_file_names(os.path.join(ref_directory,directory),type)[0]
		timestamp=np.load(os.path.join(ref_directory,directory,filename))
		time.append(timestamp[2])

	time=np.array(time)
	if np.sum(time!=np.sort(time))>0:
		print('Something is wrong, the order of the files does not follows a cronological order, as it should')
		exit()


	filename=all_file_names(os.path.join(extpath),type)[0]
	specific_time=np.load(os.path.join(extpath,filename))[2]
	specific_filename=filename[:-14]

	index=np.searchsorted(time,specific_time)-1

	print('found '+str(specific_time)+' between '+str(time[index])+' and '+str(time[index+1]))

	type="_stat.npy"
	filename=all_file_names(os.path.join(ref_directory,ref_directories[index]),type)[0]
	pre_ref=np.load(os.path.join(ref_directory,ref_directories[index],filename))[0]

	filename=all_file_names(os.path.join(ref_directory,ref_directories[index+1]),type)[0]
	post_ref=np.load(os.path.join(ref_directory,ref_directories[index+1],filename))[0]

	dt=time[index+1]-time[index]
	reference=np.multiply(pre_ref,(time[index+1]-specific_time)/dt)+np.multiply(post_ref,(specific_time-time[index])/dt)

	np.save(os.path.join(extpath,specific_filename+'_reference'),reference)


####################################################################################################

def find_nearest_index(array,value):

	# 14/08/2018 This function returns the index of the closer value to "value" inside an array

	array_shape=np.shape(array)

	index = np.abs(np.add(array,-value)).argmin()
	residual_index=index
	cycle=1
	done=0
	position_min=np.zeros(len(array_shape),dtype=int)
	while done!=1:
		length=array_shape[-cycle]
		if residual_index<length:
			position_min[-cycle]=residual_index
			done=1
		else:
			position_min[-cycle]=round(((residual_index/length) %1) *length +0.000000000000001)
			residual_index=residual_index//length
			cycle+=1

	return position_min

###################################################################################################

def clear_oscillation_central(data,framerate,force_start=0,force_end=0):

	# Created 01/11/2018
	# This function take the raw counts. analyse the fast fourier transform in a selectable interval IN THE CENTER OF THE RECORD.
	# Then search for peaks and substract the oscillation to the counts

	data=data[0]
	if force_end==0:
		force_end=len(data)

	datarestrict=data[force_start:force_end]
	sections=23
	poscentre=[np.shape(datarestrict)[1]//2,np.shape(datarestrict)[2]//2]
	record_magnitude=[]
	record_phase=[]
	record_freq=[]
	peak_index_record=[]
	peak_value_record=[]
	section_frames_record=[]
	if (len(datarestrict)//framerate)<=1:
		min_start=int(0.4//((len(datarestrict)/sections)/framerate))
		max_start=sections
	else:
		min_start=int(2//((len(datarestrict)/sections)/framerate))
		max_start=int(1+sections//(3/2))
	for i in range(min_start,max_start):
		section_frames=(i+1)*(len(datarestrict)//sections)
		section_frames_record.append(section_frames)
		datasection=datarestrict[0:section_frames,poscentre[0]-10:poscentre[0]+10,poscentre[1]-10:poscentre[1]+10]
		spectra=np.fft.fft(datasection,axis=0)
		# magnitude=np.sqrt(np.add(np.power(real,2),np.power(imag,2)))
		magnitude=2*np.abs(spectra)/len(spectra)
		record_magnitude.append(magnitude[0:len(magnitude)//2])
		phase=np.angle(spectra)
		record_phase.append(phase[0:len(magnitude)//2])
		freq=np.fft.fftfreq(len(magnitude),d=1/framerate)
		record_freq.append(freq[0:len(magnitude)//2])
		y=np.mean(magnitude,axis=(-1,-2))
		y=np.array([y for _,y in sorted(zip(freq,y))])
		x=np.sort(freq)
		plt.plot(x,y,label='size of the analysed window '+str((i+1)*(len(data)//sections)/framerate))
		index_24=int(find_nearest_index(freq,24))
		index_34=int(find_nearest_index(freq,34))
		temp=peakutils.indexes(np.mean(magnitude,axis=(-1,-2))[index_24:index_34], thres=0.15+np.abs(magnitude.min()), min_dist=(index_34-index_24)//2)
		if len(temp)==1:
			peak_index=index_24+int(temp)
			peak_index_record.append(peak_index)
			peak_value=float(np.mean(magnitude,axis=(-1,-2))[peak_index])
			peak_value_record.append(peak_value)
	record_magnitude=np.array(record_magnitude)
	record_phase=np.array(record_phase)
	record_freq=np.array(record_freq)
	peak_index_record=np.array(peak_index_record)
	peak_value_record=np.array(peak_value_record)
	section_frames_record=np.array(section_frames_record)
	plt.title('Amplitued from fast Fourier transform averaged in a wondow of '+str(10)+'pixels around '+str(poscentre)+' in counts in \n '+pathfiles+' framerate '+str(framerate)+'Hz, int. time '+str(inttime)+'ms')
	plt.xlabel('Frequency [Hz]')
	plt.ylabel('Amplitude [au]')
	plt.grid()
	plt.semilogy()
	plt.legend()
	plt.show()

	# I find the highes peak and that will be the one I use
	index=int(find_nearest_index(peak_value_record,100))
	section_frames=section_frames_record[index]
	datasection=data[0:section_frames]
	spectra=np.fft.fft(datasection,axis=0)
	# magnitude=np.sqrt(np.add(np.power(real,2),np.power(imag,2)))
	magnitude=2*np.abs(spectra)/len(spectra)
	phase=np.angle(spectra)
	freq=np.fft.fftfreq(len(magnitude),d=1/framerate)
	freq_to_erase_index=peak_index_record[index]
	freq_to_erase=freq[freq_to_erase_index]
	framenumber=np.linspace(0,len(data)-1,len(data))
	data2=data-np.multiply(magnitude[freq_to_erase_index],np.cos(np.repeat(np.expand_dims(phase[freq_to_erase_index],axis=0),len(data),axis=0)+np.repeat(np.expand_dims(np.repeat(np.expand_dims(2*np.pi*framenumber*freq_to_erase_index/(len(datasection)),axis=-1),np.shape(data)[1],axis=-1),axis=-1),np.shape(data)[2],axis=-1)))

	print('stats pf the oscillation removal')
	print('with window of size '+str(section_frames_record[index]/framerate)+'s found oscillation of frequency '+str(freq_to_erase)+'Hz')

	return [data2]
