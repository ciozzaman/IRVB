from setuptools import setup

setup(name='collect_and_eval',
      version='0.2.61',
      description='Functions to work on IR files update 2018-03-28',
      url='no url by now',
      author='Fabio Federici',
      author_email='ff645@york.ac.uk',
      license='University of York',
      packages=['collect_and_eval'],
      zip_safe=False)
